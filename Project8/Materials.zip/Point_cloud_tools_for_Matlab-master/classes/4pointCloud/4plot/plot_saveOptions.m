function plot_saveOptions(hFig)

hFig.UserData.options.SyncAttributeColors = true;
hFig.UserData.options.AdaptColors2Limits  = true;
hFig.UserData.options.AxesColor           = 'k';
hFig.UserData.options.FigureColor         = 'k';
hFig.UserData.options.NormalsScale        = 1;
hFig.UserData.options.NormalsColor        = 'm';

end
    