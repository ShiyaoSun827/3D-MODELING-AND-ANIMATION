function plot_throwError(prm)        

msg('T', ['Please check definition of ''' prm '''!']);

end
