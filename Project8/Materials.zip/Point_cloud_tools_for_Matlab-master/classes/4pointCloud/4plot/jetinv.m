function cmap = jetinv

cmap = flipud(jet);

end