function o = sing(i)

o = sin(i*pi/200);

end