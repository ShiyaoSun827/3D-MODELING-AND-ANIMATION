X = pcread('dragondata/dragon.ply');
figure(1)
hold on;
scatter3(X(:,1),X(:,2),X(:,3),"b.");

%  ---------------- Write your code here  ---------------------------